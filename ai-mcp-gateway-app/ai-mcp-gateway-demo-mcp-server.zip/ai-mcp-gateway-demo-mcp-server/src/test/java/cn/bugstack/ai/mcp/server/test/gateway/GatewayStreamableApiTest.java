package cn.bugstack.ai.mcp.server.test.gateway;

import io.modelcontextprotocol.client.McpClient;
import io.modelcontextprotocol.client.McpSyncClient;
import io.modelcontextprotocol.client.transport.HttpClientStreamableHttpTransport;
import io.modelcontextprotocol.spec.McpClientTransport;
import lombok.extern.slf4j.Slf4j;
import org.springframework.ai.chat.model.ChatModel;
import org.springframework.ai.mcp.SyncMcpToolCallbackProvider;
import org.springframework.ai.openai.OpenAiChatModel;
import org.springframework.ai.openai.OpenAiChatOptions;
import org.springframework.ai.openai.api.OpenAiApi;

import java.time.Duration;

@Slf4j
public class GatewayStreamableApiTest {

    public static void main(String[] args) throws Exception {
        OpenAiApi openAiApi = OpenAiApi.builder()
                .baseUrl("https://apis.itedus.cn")
                .apiKey("sk-2kbUfpcleloxmBtpCbC3E59f659249D39aB1D67414F97324")
                .completionsPath("v1/chat/completions")
                .embeddingsPath("v1/embeddings")
                .build();

        ChatModel chatModel = OpenAiChatModel.builder()
                .openAiApi(openAiApi)
                .defaultOptions(OpenAiChatOptions.builder()
                        .model("gpt-4.1")
                        .toolCallbacks(new SyncMcpToolCallbackProvider(streamableMcpClient_gateway()).getToolCallbacks())
                        .build())
                .build();

        System.out.println("====== 测试01 ====== \r\n");

        log.info("测试结果:{}", chatModel.call("""
                你具备什么工具能力
                """));

        System.out.println("\r\n====== 测试02 ====== \r\n");

//        log.info("测试结果:{}", chatModel.call("""
//                模拟调用工具 dummy_tool
//                """));

        log.info("测试结果:{}", chatModel.call("""
                获取公司雇员信息，信息如下；
                城市；北京
                公司；谷歌
                雇员；小傅哥
                """));
    }

    public static McpSyncClient streamableMcpClient_gateway() {
        McpClientTransport mcpClientTransport = HttpClientStreamableHttpTransport
                .builder("http://localhost:8777")
                .endpoint("/api-gateway/gateway_005/mcp")
                .build();

        McpSyncClient mcpSyncClient = McpClient.sync(mcpClientTransport).requestTimeout(Duration.ofMinutes(360)).build();
        var init_sse = mcpSyncClient.initialize();
        log.info("Tool SSE MCP Initialized {}", init_sse);

        return mcpSyncClient;
    }

}
